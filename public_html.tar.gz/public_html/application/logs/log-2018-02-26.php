<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-02-26 09:42:27 --> Severity: Warning --> mysqli::real_connect(): (HY000/1044): Access denied for user 'project'@'localhost' to database 'tdpid_logs' C:\wwwroot\apache\projects\codeigniter\tdp-indonesia\domains\tdpid.project.true\html\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2018-02-26 09:42:27 --> Unable to connect to the database
ERROR - 2018-02-26 09:42:27 --> Severity: Warning --> mysqli::real_connect(): (HY000/1044): Access denied for user 'project'@'localhost' to database 'tdpid_logs' C:\wwwroot\apache\projects\codeigniter\tdp-indonesia\domains\tdpid.project.true\html\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2018-02-26 09:42:27 --> Unable to connect to the database
ERROR - 2018-02-26 09:42:27 --> Severity: Warning --> mysqli::real_connect(): (HY000/1044): Access denied for user 'project'@'localhost' to database 'tdpid_logs' C:\wwwroot\apache\projects\codeigniter\tdp-indonesia\domains\tdpid.project.true\html\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2018-02-26 09:42:27 --> Unable to connect to the database
ERROR - 2018-02-26 09:48:56 --> Severity: Warning --> mysqli::real_connect(): (HY000/1044): Access denied for user 'project'@'localhost' to database 'tdpid_logs' C:\wwwroot\apache\projects\codeigniter\tdp-indonesia\domains\tdpid.project.true\html\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2018-02-26 09:48:56 --> Unable to connect to the database
ERROR - 2018-02-26 10:11:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/1044): Access denied for user 'project'@'localhost' to database 'tdpid_logs' C:\wwwroot\apache\projects\codeigniter\tdp-indonesia\domains\tdpid.project.true\html\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2018-02-26 10:11:07 --> Unable to connect to the database
ERROR - 2018-02-26 10:14:24 --> 404 Page Not Found: /index
ERROR - 2018-02-26 11:19:28 --> 404 Page Not Found: ../modules/web/controllers/Home/load
ERROR - 2018-02-26 11:19:44 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'tdpid_core' C:\wwwroot\apache\projects\codeigniter\tdp-indonesia\domains\tdpid.project.true\html\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2018-02-26 11:19:44 --> Unable to connect to the database
ERROR - 2018-02-26 11:20:39 --> Severity: Notice --> Undefined property: CI::$api_services C:\wwwroot\apache\projects\codeigniter\tdp-indonesia\domains\tdpid.project.true\html\system\core\Model.php 77
ERROR - 2018-02-26 11:20:39 --> Unable to load the requested class: Lib_AesEncryption
ERROR - 2018-02-26 11:21:19 --> Unable to load the requested class: Lib_AesEncryption
ERROR - 2018-02-26 11:21:36 --> 404 Page Not Found: ../modules/web/controllers/Home/js
ERROR - 2018-02-26 11:21:36 --> 404 Page Not Found: ../modules/web/controllers/Home/images
ERROR - 2018-02-26 11:21:58 --> 404 Page Not Found: ../modules/web/controllers/Home/js
ERROR - 2018-02-26 11:21:58 --> 404 Page Not Found: ../modules/web/controllers/Home/images
ERROR - 2018-02-26 11:22:12 --> 404 Page Not Found: ../modules/web/controllers/Home/js
ERROR - 2018-02-26 11:22:12 --> 404 Page Not Found: ../modules/web/controllers/Home/images
ERROR - 2018-02-26 11:22:12 --> 404 Page Not Found: ../modules/web/controllers/Home/images
ERROR - 2018-02-26 11:22:13 --> 404 Page Not Found: ../modules/web/controllers/Home/js
ERROR - 2018-02-26 11:24:11 --> 404 Page Not Found: ../modules/web/controllers/Home/images
ERROR - 2018-02-26 11:24:11 --> 404 Page Not Found: ../modules/web/controllers/Home/images
ERROR - 2018-02-26 11:24:14 --> 404 Page Not Found: ../modules/web/controllers/Home/images
ERROR - 2018-02-26 11:24:14 --> 404 Page Not Found: ../modules/web/controllers/Home/images
ERROR - 2018-02-26 11:24:18 --> 404 Page Not Found: ../modules/web/controllers/Home/images
ERROR - 2018-02-26 11:24:35 --> 404 Page Not Found: ../modules/web/controllers/Home/images
ERROR - 2018-02-26 11:24:35 --> 404 Page Not Found: ../modules/web/controllers/Home/images
ERROR - 2018-02-26 11:25:02 --> 404 Page Not Found: /index
ERROR - 2018-02-26 11:25:07 --> 404 Page Not Found: /index
ERROR - 2018-02-26 11:27:29 --> 404 Page Not Found: /index
ERROR - 2018-02-26 11:31:34 --> 404 Page Not Found: ../modules/web/controllers/Home/games.html
ERROR - 2018-02-26 11:40:48 --> 404 Page Not Found: ../modules/web/controllers/Home/single.html
ERROR - 2018-02-26 11:50:24 --> Severity: Notice --> Undefined variable: base_path C:\wwwroot\apache\projects\codeigniter\tdp-indonesia\domains\tdpid.project.true\html\application\modules\web\views\web-includes\top-header.php 24
ERROR - 2018-02-26 11:51:40 --> 404 Page Not Found: ../modules/web/controllers//index
ERROR - 2018-02-26 12:04:48 --> 404 Page Not Found: ../modules/web/controllers/Home/index.html
ERROR - 2018-02-26 13:46:19 --> 404 Page Not Found: ../modules/web/controllers//index
ERROR - 2018-02-26 13:46:19 --> 404 Page Not Found: ../modules/web/controllers//index
ERROR - 2018-02-26 13:46:19 --> 404 Page Not Found: ../modules/web/controllers//index
ERROR - 2018-02-26 13:46:19 --> 404 Page Not Found: ../modules/web/controllers//index
ERROR - 2018-02-26 13:46:19 --> 404 Page Not Found: ../modules/web/controllers//index
ERROR - 2018-02-26 13:46:19 --> 404 Page Not Found: ../modules/web/controllers//index
ERROR - 2018-02-26 13:46:19 --> 404 Page Not Found: ../modules/web/controllers//index
ERROR - 2018-02-26 13:46:19 --> 404 Page Not Found: ../modules/web/controllers//index
ERROR - 2018-02-26 13:46:19 --> 404 Page Not Found: ../modules/web/controllers//index
ERROR - 2018-02-26 13:47:17 --> 404 Page Not Found: ../modules/web/controllers//index
ERROR - 2018-02-26 13:47:17 --> 404 Page Not Found: ../modules/web/controllers//index
ERROR - 2018-02-26 13:47:17 --> 404 Page Not Found: ../modules/web/controllers//index
ERROR - 2018-02-26 13:47:17 --> 404 Page Not Found: ../modules/web/controllers//index
ERROR - 2018-02-26 13:47:17 --> 404 Page Not Found: ../modules/web/controllers//index
ERROR - 2018-02-26 13:47:17 --> 404 Page Not Found: ../modules/web/controllers//index
ERROR - 2018-02-26 13:47:17 --> 404 Page Not Found: ../modules/web/controllers//index
ERROR - 2018-02-26 13:47:17 --> 404 Page Not Found: ../modules/web/controllers//index
ERROR - 2018-02-26 13:47:17 --> 404 Page Not Found: ../modules/web/controllers//index
ERROR - 2018-02-26 13:56:53 --> 404 Page Not Found: ../modules/web/controllers//index
ERROR - 2018-02-26 13:56:55 --> 404 Page Not Found: ../modules/web/controllers//index
ERROR - 2018-02-26 13:56:55 --> 404 Page Not Found: ../modules/web/controllers//index
ERROR - 2018-02-26 13:56:55 --> 404 Page Not Found: ../modules/web/controllers//index
ERROR - 2018-02-26 13:56:55 --> 404 Page Not Found: ../modules/web/controllers//index
ERROR - 2018-02-26 13:56:55 --> 404 Page Not Found: ../modules/web/controllers//index
ERROR - 2018-02-26 13:56:55 --> 404 Page Not Found: ../modules/web/controllers//index
ERROR - 2018-02-26 13:56:55 --> 404 Page Not Found: ../modules/web/controllers//index
ERROR - 2018-02-26 13:56:55 --> 404 Page Not Found: ../modules/web/controllers//index
ERROR - 2018-02-26 14:03:48 --> Severity: Notice --> Trying to get property of non-object C:\wwwroot\apache\projects\codeigniter\tdp-indonesia\domains\tdpid.project.true\html\application\modules\dashboard\controllers\Addressbook.php 27
ERROR - 2018-02-26 14:03:48 --> Severity: Notice --> Trying to get property of non-object C:\wwwroot\apache\projects\codeigniter\tdp-indonesia\domains\tdpid.project.true\html\application\modules\dashboard\controllers\Addressbook.php 134
ERROR - 2018-02-26 14:03:48 --> Severity: Notice --> Trying to get property of non-object C:\wwwroot\apache\projects\codeigniter\tdp-indonesia\domains\tdpid.project.true\html\application\modules\dashboard\controllers\Addressbook.php 137
ERROR - 2018-02-26 14:03:48 --> Severity: Notice --> Trying to get property of non-object C:\wwwroot\apache\projects\codeigniter\tdp-indonesia\domains\tdpid.project.true\html\application\modules\dashboard\controllers\Addressbook.php 193
ERROR - 2018-02-26 14:03:48 --> 404 Page Not Found: /index
ERROR - 2018-02-26 15:30:19 --> 404 Page Not Found: ../modules/web/controllers/Home/single.html
ERROR - 2018-02-26 16:30:42 --> Severity: error --> Exception: Class 'VerotUpload' not found C:\wwwroot\apache\projects\codeigniter\tdp-indonesia\domains\tdpid.project.true\html\application\modules\dashboard\controllers\Users.php 742
ERROR - 2018-02-26 16:36:59 --> Severity: error --> Exception: Class 'VerotUpload' not found C:\wwwroot\apache\projects\codeigniter\tdp-indonesia\domains\tdpid.project.true\html\application\modules\dashboard\controllers\Users.php 742
ERROR - 2018-02-26 16:48:02 --> 404 Page Not Found: ../modules/dashboard/controllers/Users/load
ERROR - 2018-02-26 16:48:11 --> Severity: Notice --> Undefined property: CI::$mod_addressbook C:\wwwroot\apache\projects\codeigniter\tdp-indonesia\domains\tdpid.project.true\html\application\third_party\MX\Controller.php 59
ERROR - 2018-02-26 16:48:11 --> Severity: error --> Exception: Call to a member function get_group_data_by() on null C:\wwwroot\apache\projects\codeigniter\tdp-indonesia\domains\tdpid.project.true\html\application\modules\dashboard\controllers\Menu.php 52
ERROR - 2018-02-26 16:48:25 --> 404 Page Not Found: ../modules/dashboard/controllers/Menu/add
ERROR - 2018-02-26 17:03:11 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ')' C:\wwwroot\apache\projects\codeigniter\tdp-indonesia\domains\tdpid.project.true\html\application\modules\dashboard\controllers\Menu.php 43
ERROR - 2018-02-26 17:03:24 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_driver::result() C:\wwwroot\apache\projects\codeigniter\tdp-indonesia\domains\tdpid.project.true\html\application\modules\dashboard\models\Model_menu.php 22
ERROR - 2018-02-26 17:04:56 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_driver::result() C:\wwwroot\apache\projects\codeigniter\tdp-indonesia\domains\tdpid.project.true\html\application\modules\dashboard\models\Model_menu.php 22
ERROR - 2018-02-26 17:09:16 --> Severity: Notice --> Undefined index: match C:\wwwroot\apache\projects\codeigniter\tdp-indonesia\domains\tdpid.project.true\html\application\modules\dashboard\views\dashboard-includes\sidebar.php 24
ERROR - 2018-02-26 17:09:16 --> Severity: Notice --> Undefined index: match C:\wwwroot\apache\projects\codeigniter\tdp-indonesia\domains\tdpid.project.true\html\application\modules\dashboard\views\dashboard-includes\sidebar.php 31
ERROR - 2018-02-26 17:09:16 --> Severity: Notice --> Undefined index: match C:\wwwroot\apache\projects\codeigniter\tdp-indonesia\domains\tdpid.project.true\html\application\modules\dashboard\views\dashboard-includes\sidebar.php 41
ERROR - 2018-02-26 17:09:16 --> Severity: Notice --> Undefined index: match C:\wwwroot\apache\projects\codeigniter\tdp-indonesia\domains\tdpid.project.true\html\application\modules\dashboard\views\dashboard-includes\sidebar.php 49
ERROR - 2018-02-26 17:09:16 --> Severity: Notice --> Undefined index: match C:\wwwroot\apache\projects\codeigniter\tdp-indonesia\domains\tdpid.project.true\html\application\modules\dashboard\views\dashboard-includes\sidebar.php 52
ERROR - 2018-02-26 17:09:16 --> Severity: Notice --> Undefined index: match C:\wwwroot\apache\projects\codeigniter\tdp-indonesia\domains\tdpid.project.true\html\application\modules\dashboard\views\dashboard-includes\sidebar.php 55
ERROR - 2018-02-26 17:09:16 --> Severity: Notice --> Undefined index: match C:\wwwroot\apache\projects\codeigniter\tdp-indonesia\domains\tdpid.project.true\html\application\modules\dashboard\views\dashboard-includes\sidebar.php 64
ERROR - 2018-02-26 17:09:16 --> Severity: Notice --> Undefined index: match C:\wwwroot\apache\projects\codeigniter\tdp-indonesia\domains\tdpid.project.true\html\application\modules\dashboard\views\dashboard-includes\sidebar.php 72
ERROR - 2018-02-26 17:09:16 --> Severity: Notice --> Undefined index: match C:\wwwroot\apache\projects\codeigniter\tdp-indonesia\domains\tdpid.project.true\html\application\modules\dashboard\views\dashboard-includes\sidebar.php 75
ERROR - 2018-02-26 17:09:16 --> Severity: Notice --> Undefined index: match C:\wwwroot\apache\projects\codeigniter\tdp-indonesia\domains\tdpid.project.true\html\application\modules\dashboard\views\dashboard-includes\sidebar.php 80
ERROR - 2018-02-26 17:09:16 --> Severity: Notice --> Undefined index: match C:\wwwroot\apache\projects\codeigniter\tdp-indonesia\domains\tdpid.project.true\html\application\modules\dashboard\views\dashboard-includes\sidebar.php 88
ERROR - 2018-02-26 17:09:16 --> Severity: Notice --> Undefined index: match C:\wwwroot\apache\projects\codeigniter\tdp-indonesia\domains\tdpid.project.true\html\application\modules\dashboard\views\dashboard-includes\sidebar.php 91
ERROR - 2018-02-26 17:09:16 --> Severity: Notice --> Undefined index: match C:\wwwroot\apache\projects\codeigniter\tdp-indonesia\domains\tdpid.project.true\html\application\modules\dashboard\views\dashboard-includes\sidebar.php 99
ERROR - 2018-02-26 17:09:16 --> Severity: Notice --> Undefined index: match C:\wwwroot\apache\projects\codeigniter\tdp-indonesia\domains\tdpid.project.true\html\application\modules\dashboard\views\dashboard-includes\sidebar.php 107
ERROR - 2018-02-26 17:09:16 --> Severity: Notice --> Undefined index: match C:\wwwroot\apache\projects\codeigniter\tdp-indonesia\domains\tdpid.project.true\html\application\modules\dashboard\views\dashboard-includes\sidebar.php 115
ERROR - 2018-02-26 17:09:16 --> Severity: Notice --> Undefined index: match C:\wwwroot\apache\projects\codeigniter\tdp-indonesia\domains\tdpid.project.true\html\application\modules\dashboard\views\dashboard-includes\sidebar.php 118
ERROR - 2018-02-26 17:09:16 --> Severity: Notice --> Undefined index: match C:\wwwroot\apache\projects\codeigniter\tdp-indonesia\domains\tdpid.project.true\html\application\modules\dashboard\views\dashboard-includes\sidebar.php 123
ERROR - 2018-02-26 17:09:16 --> Severity: Notice --> Undefined index: match C:\wwwroot\apache\projects\codeigniter\tdp-indonesia\domains\tdpid.project.true\html\application\modules\dashboard\views\dashboard-includes\sidebar.php 131
ERROR - 2018-02-26 17:09:16 --> Severity: Notice --> Undefined index: match C:\wwwroot\apache\projects\codeigniter\tdp-indonesia\domains\tdpid.project.true\html\application\modules\dashboard\views\dashboard-includes\sidebar.php 134
ERROR - 2018-02-26 17:09:16 --> Severity: Notice --> Undefined index: match C:\wwwroot\apache\projects\codeigniter\tdp-indonesia\domains\tdpid.project.true\html\application\modules\dashboard\views\dashboard-includes\sidebar.php 140
ERROR - 2018-02-26 17:09:16 --> Severity: Notice --> Undefined index: match C:\wwwroot\apache\projects\codeigniter\tdp-indonesia\domains\tdpid.project.true\html\application\modules\dashboard\views\dashboard-includes\sidebar.php 143
ERROR - 2018-02-26 17:09:16 --> Severity: Notice --> Undefined variable: search_text C:\wwwroot\apache\projects\codeigniter\tdp-indonesia\domains\tdpid.project.true\html\application\modules\dashboard\views\menu\menu-lists.php 99
ERROR - 2018-02-26 17:09:51 --> Severity: Notice --> Undefined variable: search_text C:\wwwroot\apache\projects\codeigniter\tdp-indonesia\domains\tdpid.project.true\html\application\modules\dashboard\views\menu\menu-lists.php 99
ERROR - 2018-02-26 17:25:13 --> 404 Page Not Found: ../modules/dashboard/controllers/Menu/footer
ERROR - 2018-02-26 17:41:52 --> Severity: error --> Exception: Table 'tdpid_dashboard.web_menu_types_item' doesn't exist C:\wwwroot\apache\projects\codeigniter\tdp-indonesia\domains\tdpid.project.true\html\application\modules\dashboard\libraries\Lib_imzers.php 202
ERROR - 2018-02-26 17:42:34 --> Severity: error --> Exception: Unknown column 'type_code' in 'where clause' C:\wwwroot\apache\projects\codeigniter\tdp-indonesia\domains\tdpid.project.true\html\system\database\drivers\mysqli\mysqli_driver.php 305
ERROR - 2018-02-26 17:43:03 --> Severity: error --> Exception: Unknown column 'type_code' in 'where clause' C:\wwwroot\apache\projects\codeigniter\tdp-indonesia\domains\tdpid.project.true\html\system\database\drivers\mysqli\mysqli_driver.php 305
ERROR - 2018-02-26 17:45:28 --> Severity: error --> Exception: Unknown column 'type_code' in 'where clause' C:\wwwroot\apache\projects\codeigniter\tdp-indonesia\domains\tdpid.project.true\html\system\database\drivers\mysqli\mysqli_driver.php 305
ERROR - 2018-02-26 17:45:49 --> Severity: error --> Exception: Unknown column 'type_code' in 'where clause' C:\wwwroot\apache\projects\codeigniter\tdp-indonesia\domains\tdpid.project.true\html\system\database\drivers\mysqli\mysqli_driver.php 305
ERROR - 2018-02-26 17:49:00 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_result::fetch_object() C:\wwwroot\apache\projects\codeigniter\tdp-indonesia\domains\tdpid.project.true\html\application\modules\dashboard\models\Model_menu.php 59
ERROR - 2018-02-26 17:50:19 --> Severity: error --> Exception: Call to a member function row() on array C:\wwwroot\apache\projects\codeigniter\tdp-indonesia\domains\tdpid.project.true\html\application\modules\dashboard\models\Model_menu.php 59
ERROR - 2018-02-26 18:00:57 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_driver::result() C:\wwwroot\apache\projects\codeigniter\tdp-indonesia\domains\tdpid.project.true\html\application\modules\dashboard\models\Model_menu.php 101
