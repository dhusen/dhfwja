<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-05-29 08:45:36 --> 404 Page Not Found: /index
ERROR - 2018-05-29 08:50:10 --> 404 Page Not Found: /index
ERROR - 2018-05-29 08:50:27 --> 404 Page Not Found: /index
ERROR - 2018-05-29 08:50:27 --> 404 Page Not Found: /index
ERROR - 2018-05-29 09:56:03 --> 404 Page Not Found: /index
ERROR - 2018-05-29 09:56:11 --> 404 Page Not Found: /index
ERROR - 2018-05-29 11:53:44 --> 404 Page Not Found: /index
ERROR - 2018-05-29 13:02:51 --> 404 Page Not Found: /index
ERROR - 2018-05-29 13:02:56 --> 404 Page Not Found: /index
ERROR - 2018-05-29 20:16:04 --> 404 Page Not Found: /index
ERROR - 2018-05-29 20:16:07 --> 404 Page Not Found: /index
ERROR - 2018-05-29 22:41:21 --> 404 Page Not Found: /index
