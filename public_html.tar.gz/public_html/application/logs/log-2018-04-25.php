<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-04-25 00:19:58 --> 404 Page Not Found: /index
ERROR - 2018-04-25 00:20:06 --> 404 Page Not Found: /index
ERROR - 2018-04-25 01:35:12 --> Severity: error --> Exception: CURL error: OpenSSL SSL_connect: SSL_ERROR_SYSCALL in connection to api.kraken.com:443  /home/dhfwjaco/public_html/application/vendor/psr/payward/kraken-api-client/php/KrakenAPI.php 88
ERROR - 2018-04-25 03:15:21 --> Severity: error --> Exception: JSON decode error /home/dhfwjaco/public_html/application/vendor/psr/payward/kraken-api-client/php/KrakenAPI.php 93
ERROR - 2018-04-25 16:33:36 --> 404 Page Not Found: /index
ERROR - 2018-04-25 16:33:41 --> 404 Page Not Found: /index
ERROR - 2018-04-25 17:49:20 --> 404 Page Not Found: /index
ERROR - 2018-04-25 17:49:29 --> 404 Page Not Found: /index
ERROR - 2018-04-25 19:20:23 --> Severity: error --> Exception: JSON decode error /home/dhfwjaco/public_html/application/vendor/psr/payward/kraken-api-client/php/KrakenAPI.php 93
ERROR - 2018-04-25 20:09:31 --> 404 Page Not Found: /index
ERROR - 2018-04-25 20:09:42 --> 404 Page Not Found: /index
ERROR - 2018-04-25 20:09:43 --> 404 Page Not Found: /index
ERROR - 2018-04-25 20:09:43 --> 404 Page Not Found: /index
ERROR - 2018-04-25 22:20:19 --> Severity: error --> Exception: JSON decode error /home/dhfwjaco/public_html/application/vendor/psr/payward/kraken-api-client/php/KrakenAPI.php 93
