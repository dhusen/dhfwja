<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-06-05 04:50:29 --> 404 Page Not Found: /index
ERROR - 2018-06-05 04:50:30 --> 404 Page Not Found: /index
ERROR - 2018-06-05 09:21:40 --> Severity: error --> Exception: MySQL server has gone away /home/dhfwjaco/public_html/system/database/drivers/mysqli/mysqli_driver.php 305
ERROR - 2018-06-05 09:21:40 --> Severity: error --> Exception: MySQL server has gone away /home/dhfwjaco/public_html/system/database/drivers/mysqli/mysqli_driver.php 305
ERROR - 2018-06-05 10:05:30 --> 404 Page Not Found: /index
ERROR - 2018-06-05 10:05:30 --> 404 Page Not Found: /index
ERROR - 2018-06-05 10:05:36 --> 404 Page Not Found: /index
ERROR - 2018-06-05 10:05:36 --> 404 Page Not Found: /index
ERROR - 2018-06-05 17:00:19 --> 404 Page Not Found: /index
ERROR - 2018-06-05 23:49:32 --> 404 Page Not Found: /index
