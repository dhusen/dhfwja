<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-03-18 07:48:05 --> Severity: error --> Exception: CURL error: Could not resolve host: api.kraken.com /home/www/domains/myarena.id/domains/mutasi.myarena.id/html/application/vendor/psr/payward/kraken-api-client/php/KrakenAPI.php 88
