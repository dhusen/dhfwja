<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-05-16 11:31:29 --> Severity: error --> Exception: MySQL server has gone away /home/dhfwjaco/public_html/system/database/drivers/mysqli/mysqli_driver.php 305
ERROR - 2018-05-16 11:31:29 --> Severity: error --> Exception: MySQL server has gone away /home/dhfwjaco/public_html/system/database/drivers/mysqli/mysqli_driver.php 305
ERROR - 2018-05-16 14:50:18 --> Severity: error --> Exception: JSON decode error /home/dhfwjaco/public_html/application/vendor/psr/payward/kraken-api-client/php/KrakenAPI.php 93
ERROR - 2018-05-16 14:50:21 --> Severity: error --> Exception: JSON decode error /home/dhfwjaco/public_html/application/vendor/psr/payward/kraken-api-client/php/KrakenAPI.php 93
ERROR - 2018-05-16 21:09:05 --> 404 Page Not Found: /index
ERROR - 2018-05-16 21:17:49 --> 404 Page Not Found: /index
ERROR - 2018-05-16 21:22:33 --> 404 Page Not Found: /index
ERROR - 2018-05-16 21:22:49 --> 404 Page Not Found: /index
ERROR - 2018-05-16 21:22:50 --> 404 Page Not Found: /index
ERROR - 2018-05-16 21:51:51 --> 404 Page Not Found: /index
ERROR - 2018-05-16 21:52:05 --> 404 Page Not Found: /index
