<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-05-27 21:15:28 --> 404 Page Not Found: /index
ERROR - 2018-05-27 21:15:28 --> 404 Page Not Found: /index
