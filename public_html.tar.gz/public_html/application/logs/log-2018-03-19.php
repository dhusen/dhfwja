<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-03-19 00:00:02 --> Severity: error --> Exception: JSON decode error /home/www/domains/myarena.id/domains/mutasi.myarena.id/html/application/vendor/psr/payward/kraken-api-client/php/KrakenAPI.php 93
ERROR - 2018-03-19 04:48:19 --> Severity: error --> Exception: JSON decode error /home/www/domains/myarena.id/domains/mutasi.myarena.id/html/application/vendor/psr/payward/kraken-api-client/php/KrakenAPI.php 93
ERROR - 2018-03-19 04:50:19 --> Severity: error --> Exception: JSON decode error /home/www/domains/myarena.id/domains/mutasi.myarena.id/html/application/vendor/psr/payward/kraken-api-client/php/KrakenAPI.php 93
ERROR - 2018-03-19 04:52:02 --> Severity: error --> Exception: JSON decode error /home/www/domains/myarena.id/domains/mutasi.myarena.id/html/application/vendor/psr/payward/kraken-api-client/php/KrakenAPI.php 93
ERROR - 2018-03-19 04:58:04 --> Severity: error --> Exception: JSON decode error /home/www/domains/myarena.id/domains/mutasi.myarena.id/html/application/vendor/psr/payward/kraken-api-client/php/KrakenAPI.php 93
ERROR - 2018-03-19 05:00:03 --> Severity: error --> Exception: JSON decode error /home/www/domains/myarena.id/domains/mutasi.myarena.id/html/application/vendor/psr/payward/kraken-api-client/php/KrakenAPI.php 93
ERROR - 2018-03-19 05:02:08 --> Severity: error --> Exception: JSON decode error /home/www/domains/myarena.id/domains/mutasi.myarena.id/html/application/vendor/psr/payward/kraken-api-client/php/KrakenAPI.php 93
ERROR - 2018-03-19 05:06:04 --> Severity: error --> Exception: JSON decode error /home/www/domains/myarena.id/domains/mutasi.myarena.id/html/application/vendor/psr/payward/kraken-api-client/php/KrakenAPI.php 93
ERROR - 2018-03-19 05:08:02 --> Severity: error --> Exception: JSON decode error /home/www/domains/myarena.id/domains/mutasi.myarena.id/html/application/vendor/psr/payward/kraken-api-client/php/KrakenAPI.php 93
ERROR - 2018-03-19 05:10:02 --> Severity: error --> Exception: JSON decode error /home/www/domains/myarena.id/domains/mutasi.myarena.id/html/application/vendor/psr/payward/kraken-api-client/php/KrakenAPI.php 93
ERROR - 2018-03-19 05:12:04 --> Severity: error --> Exception: JSON decode error /home/www/domains/myarena.id/domains/mutasi.myarena.id/html/application/vendor/psr/payward/kraken-api-client/php/KrakenAPI.php 93
ERROR - 2018-03-19 05:20:02 --> Severity: error --> Exception: JSON decode error /home/www/domains/myarena.id/domains/mutasi.myarena.id/html/application/vendor/psr/payward/kraken-api-client/php/KrakenAPI.php 93
ERROR - 2018-03-19 13:08:04 --> Severity: error --> Exception: JSON decode error /home/www/domains/myarena.id/domains/mutasi.myarena.id/html/application/vendor/psr/payward/kraken-api-client/php/KrakenAPI.php 93
ERROR - 2018-03-19 21:22:06 --> Severity: error --> Exception: JSON decode error /home/www/domains/myarena.id/domains/mutasi.myarena.id/html/application/vendor/psr/payward/kraken-api-client/php/KrakenAPI.php 93
ERROR - 2018-03-19 21:24:04 --> Severity: error --> Exception: JSON decode error /home/www/domains/myarena.id/domains/mutasi.myarena.id/html/application/vendor/psr/payward/kraken-api-client/php/KrakenAPI.php 93
ERROR - 2018-03-19 21:26:03 --> Severity: error --> Exception: JSON decode error /home/www/domains/myarena.id/domains/mutasi.myarena.id/html/application/vendor/psr/payward/kraken-api-client/php/KrakenAPI.php 93
ERROR - 2018-03-19 21:28:03 --> Severity: error --> Exception: JSON decode error /home/www/domains/myarena.id/domains/mutasi.myarena.id/html/application/vendor/psr/payward/kraken-api-client/php/KrakenAPI.php 93
ERROR - 2018-03-19 21:32:05 --> Severity: error --> Exception: JSON decode error /home/www/domains/myarena.id/domains/mutasi.myarena.id/html/application/vendor/psr/payward/kraken-api-client/php/KrakenAPI.php 93
ERROR - 2018-03-19 21:38:02 --> Severity: error --> Exception: JSON decode error /home/www/domains/myarena.id/domains/mutasi.myarena.id/html/application/vendor/psr/payward/kraken-api-client/php/KrakenAPI.php 93
