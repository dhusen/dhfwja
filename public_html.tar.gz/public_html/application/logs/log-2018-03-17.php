<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-03-17 20:38:19 --> Severity: error --> Exception: JSON decode error /home/www/domains/myarena.id/domains/mutasi.myarena.id/html/application/vendor/psr/payward/kraken-api-client/php/KrakenAPI.php 93
