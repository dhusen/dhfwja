<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-02-23 20:48:45 --> 404 Page Not Found: /index
ERROR - 2018-02-23 20:48:46 --> 404 Page Not Found: /index
ERROR - 2018-02-23 20:48:47 --> 404 Page Not Found: /index
ERROR - 2018-02-23 20:54:24 --> 404 Page Not Found: /index
ERROR - 2018-02-23 21:14:01 --> Severity: error --> Exception: Class 'AltoRouter' not found C:\Server\Webroot\projects\domains\tdp-indonesia\domains\truedigitalplus.project.true\html\application\modules\dashboard\libraries\Lib_authentication.php 56
ERROR - 2018-02-23 21:37:16 --> Severity: error --> Exception: Class 'AltoRouter' not found C:\Server\Webroot\projects\domains\tdp-indonesia\domains\truedigitalplus.project.true\html\application\modules\dashboard\libraries\Lib_authentication.php 56
