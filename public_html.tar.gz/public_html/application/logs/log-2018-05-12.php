<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-05-12 00:01:29 --> Severity: error --> Exception: MySQL server has gone away /home/dhfwjaco/public_html/system/database/drivers/mysqli/mysqli_driver.php 305
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-05-12 00:01:29 --> Severity: error --> Exception: MySQL server has gone away /home/dhfwjaco/public_html/system/database/drivers/mysqli/mysqli_driver.php 305
ERROR - 2018-05-12 00:31:29 --> Severity: error --> Exception: MySQL server has gone away /home/dhfwjaco/public_html/system/database/drivers/mysqli/mysqli_driver.php 305
ERROR - 2018-05-12 00:31:29 --> Severity: error --> Exception: MySQL server has gone away /home/dhfwjaco/public_html/system/database/drivers/mysqli/mysqli_driver.php 305
ERROR - 2018-05-12 05:47:39 --> 404 Page Not Found: /index
ERROR - 2018-05-12 20:02:44 --> 404 Page Not Found: /index
ERROR - 2018-05-12 23:15:27 --> 404 Page Not Found: /index
ERROR - 2018-05-12 23:15:35 --> 404 Page Not Found: /index
