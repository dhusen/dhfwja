<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-05-09 01:28:53 --> 404 Page Not Found: /index
ERROR - 2018-05-09 13:12:57 --> 404 Page Not Found: /index
ERROR - 2018-05-09 13:13:05 --> 404 Page Not Found: /index
ERROR - 2018-05-09 14:13:12 --> 404 Page Not Found: /index
ERROR - 2018-05-09 14:13:26 --> 404 Page Not Found: /index
ERROR - 2018-05-09 14:13:26 --> 404 Page Not Found: /index
ERROR - 2018-05-09 14:31:29 --> Severity: error --> Exception: MySQL server has gone away /home/dhfwjaco/public_html/system/database/drivers/mysqli/mysqli_driver.php 305
ERROR - 2018-05-09 14:31:29 --> Severity: error --> Exception: MySQL server has gone away /home/dhfwjaco/public_html/system/database/drivers/mysqli/mysqli_driver.php 305
ERROR - 2018-05-09 15:15:50 --> 404 Page Not Found: /index
ERROR - 2018-05-09 16:18:32 --> 404 Page Not Found: /index
ERROR - 2018-05-09 16:18:37 --> 404 Page Not Found: /index
ERROR - 2018-05-09 16:24:16 --> 404 Page Not Found: /index
ERROR - 2018-05-09 16:26:36 --> 404 Page Not Found: /index
ERROR - 2018-05-09 16:26:38 --> 404 Page Not Found: /index
ERROR - 2018-05-09 17:42:56 --> 404 Page Not Found: /index
ERROR - 2018-05-09 17:47:04 --> 404 Page Not Found: /index
ERROR - 2018-05-09 17:47:05 --> 404 Page Not Found: /index
ERROR - 2018-05-09 19:25:57 --> 404 Page Not Found: /index
ERROR - 2018-05-09 19:26:07 --> 404 Page Not Found: /index
ERROR - 2018-05-09 19:40:17 --> Severity: error --> Exception: JSON decode error /home/dhfwjaco/public_html/application/vendor/psr/payward/kraken-api-client/php/KrakenAPI.php 93
ERROR - 2018-05-09 19:40:18 --> Severity: error --> Exception: JSON decode error /home/dhfwjaco/public_html/application/vendor/psr/payward/kraken-api-client/php/KrakenAPI.php 93
