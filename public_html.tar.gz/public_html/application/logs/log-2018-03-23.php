<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-03-23 02:30:12 --> Severity: error --> Exception: JSON decode error /home/www/domains/myarena.id/domains/mutasi.myarena.id/html/application/vendor/psr/payward/kraken-api-client/php/KrakenAPI.php 93
