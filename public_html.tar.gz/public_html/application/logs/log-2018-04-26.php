<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-04-26 00:35:50 --> 404 Page Not Found: /index
ERROR - 2018-04-26 11:48:54 --> 404 Page Not Found: /index
ERROR - 2018-04-26 11:48:59 --> 404 Page Not Found: /index
ERROR - 2018-04-26 15:11:40 --> 404 Page Not Found: /index
ERROR - 2018-04-26 15:11:50 --> 404 Page Not Found: /index
ERROR - 2018-04-26 18:03:28 --> 404 Page Not Found: /index
ERROR - 2018-04-26 18:03:37 --> 404 Page Not Found: /index
ERROR - 2018-04-26 18:08:08 --> 404 Page Not Found: /index
ERROR - 2018-04-26 18:08:09 --> 404 Page Not Found: /index
ERROR - 2018-04-26 18:08:15 --> 404 Page Not Found: /index
ERROR - 2018-04-26 18:08:15 --> 404 Page Not Found: /index
ERROR - 2018-04-26 18:10:09 --> Severity: Notice --> Undefined index: enabled_data /home/dhfwjaco/public_html/application/modules/cryptocurrency/views/ticker/ticker-add-enabled.php 106
ERROR - 2018-04-26 18:10:09 --> Severity: Notice --> Trying to get property of non-object /home/dhfwjaco/public_html/application/modules/cryptocurrency/views/ticker/ticker-add-enabled.php 106
ERROR - 2018-04-26 18:10:09 --> Severity: Notice --> Undefined index: enabled_data /home/dhfwjaco/public_html/application/modules/cryptocurrency/views/ticker/ticker-add-enabled.php 106
ERROR - 2018-04-26 18:10:09 --> Severity: Notice --> Trying to get property of non-object /home/dhfwjaco/public_html/application/modules/cryptocurrency/views/ticker/ticker-add-enabled.php 106
ERROR - 2018-04-26 18:10:09 --> Severity: Notice --> Undefined index: enabled_data /home/dhfwjaco/public_html/application/modules/cryptocurrency/views/ticker/ticker-add-enabled.php 106
ERROR - 2018-04-26 18:10:09 --> Severity: Notice --> Trying to get property of non-object /home/dhfwjaco/public_html/application/modules/cryptocurrency/views/ticker/ticker-add-enabled.php 106
ERROR - 2018-04-26 18:10:09 --> Severity: Notice --> Undefined index: enabled_data /home/dhfwjaco/public_html/application/modules/cryptocurrency/views/ticker/ticker-add-enabled.php 156
ERROR - 2018-04-26 18:10:09 --> Severity: Notice --> Trying to get property of non-object /home/dhfwjaco/public_html/application/modules/cryptocurrency/views/ticker/ticker-add-enabled.php 156
ERROR - 2018-04-26 18:10:09 --> Severity: Notice --> Undefined index: enabled_data /home/dhfwjaco/public_html/application/modules/cryptocurrency/views/ticker/ticker-add-enabled.php 156
ERROR - 2018-04-26 18:10:09 --> Severity: Notice --> Trying to get property of non-object /home/dhfwjaco/public_html/application/modules/cryptocurrency/views/ticker/ticker-add-enabled.php 156
ERROR - 2018-04-26 18:10:09 --> Severity: Notice --> Undefined index: enabled_data /home/dhfwjaco/public_html/application/modules/cryptocurrency/views/ticker/ticker-add-enabled.php 156
ERROR - 2018-04-26 18:10:09 --> Severity: Notice --> Trying to get property of non-object /home/dhfwjaco/public_html/application/modules/cryptocurrency/views/ticker/ticker-add-enabled.php 156
ERROR - 2018-04-26 18:55:21 --> Severity: error --> Exception: JSON decode error /home/dhfwjaco/public_html/application/vendor/psr/payward/kraken-api-client/php/KrakenAPI.php 93
ERROR - 2018-04-26 19:10:08 --> Severity: error --> Exception: JSON decode error /home/dhfwjaco/public_html/application/vendor/psr/payward/kraken-api-client/php/KrakenAPI.php 93
ERROR - 2018-04-26 19:30:11 --> Severity: error --> Exception: JSON decode error /home/dhfwjaco/public_html/application/vendor/psr/payward/kraken-api-client/php/KrakenAPI.php 93
ERROR - 2018-04-26 19:35:25 --> Severity: error --> Exception: JSON decode error /home/dhfwjaco/public_html/application/vendor/psr/payward/kraken-api-client/php/KrakenAPI.php 93
ERROR - 2018-04-26 19:40:19 --> Severity: error --> Exception: JSON decode error /home/dhfwjaco/public_html/application/vendor/psr/payward/kraken-api-client/php/KrakenAPI.php 93
ERROR - 2018-04-26 19:50:04 --> Severity: error --> Exception: JSON decode error /home/dhfwjaco/public_html/application/vendor/psr/payward/kraken-api-client/php/KrakenAPI.php 93
