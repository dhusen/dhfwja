<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-04-22 00:15:08 --> Severity: error --> Exception: JSON decode error /home/dhfwjaco/public_html/application/vendor/psr/payward/kraken-api-client/php/KrakenAPI.php 93
ERROR - 2018-04-22 00:20:21 --> Severity: error --> Exception: JSON decode error /home/dhfwjaco/public_html/application/vendor/psr/payward/kraken-api-client/php/KrakenAPI.php 93
ERROR - 2018-04-22 00:25:12 --> Severity: error --> Exception: JSON decode error /home/dhfwjaco/public_html/application/vendor/psr/payward/kraken-api-client/php/KrakenAPI.php 93
ERROR - 2018-04-22 00:30:32 --> Severity: error --> Exception: JSON decode error /home/dhfwjaco/public_html/application/vendor/psr/payward/kraken-api-client/php/KrakenAPI.php 93
ERROR - 2018-04-22 03:05:37 --> 404 Page Not Found: /index
ERROR - 2018-04-22 03:05:40 --> 404 Page Not Found: /index
ERROR - 2018-04-22 03:05:45 --> 404 Page Not Found: /index
ERROR - 2018-04-22 19:16:54 --> 404 Page Not Found: /index
