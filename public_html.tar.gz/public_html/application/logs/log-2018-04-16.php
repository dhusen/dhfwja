<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-04-16 02:21:56 --> 404 Page Not Found: /index
ERROR - 2018-04-16 02:22:01 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/dhfwjaco/public_html/application/modules/dashboard/models/Model_account.php 57
ERROR - 2018-04-16 02:22:02 --> 404 Page Not Found: /index
ERROR - 2018-04-16 02:40:09 --> 404 Page Not Found: /index
ERROR - 2018-04-16 02:40:38 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/dhfwjaco/public_html/application/modules/dashboard/models/Model_account.php 57
ERROR - 2018-04-16 02:40:39 --> 404 Page Not Found: /index
ERROR - 2018-04-16 02:40:39 --> 404 Page Not Found: /index
ERROR - 2018-04-16 02:41:33 --> Severity: Notice --> Undefined index: enabled_data /home/dhfwjaco/public_html/application/modules/cryptocurrency/views/ticker/ticker-add-enabled.php 106
ERROR - 2018-04-16 02:41:33 --> Severity: Notice --> Trying to get property 'cryptocurrency_from_realcurrency' of non-object /home/dhfwjaco/public_html/application/modules/cryptocurrency/views/ticker/ticker-add-enabled.php 106
ERROR - 2018-04-16 02:41:33 --> Severity: Notice --> Undefined index: enabled_data /home/dhfwjaco/public_html/application/modules/cryptocurrency/views/ticker/ticker-add-enabled.php 106
ERROR - 2018-04-16 02:41:33 --> Severity: Notice --> Trying to get property 'cryptocurrency_from_realcurrency' of non-object /home/dhfwjaco/public_html/application/modules/cryptocurrency/views/ticker/ticker-add-enabled.php 106
ERROR - 2018-04-16 02:41:33 --> Severity: Notice --> Undefined index: enabled_data /home/dhfwjaco/public_html/application/modules/cryptocurrency/views/ticker/ticker-add-enabled.php 106
ERROR - 2018-04-16 02:41:33 --> Severity: Notice --> Trying to get property 'cryptocurrency_from_realcurrency' of non-object /home/dhfwjaco/public_html/application/modules/cryptocurrency/views/ticker/ticker-add-enabled.php 106
ERROR - 2018-04-16 02:41:33 --> Severity: Notice --> Undefined index: enabled_data /home/dhfwjaco/public_html/application/modules/cryptocurrency/views/ticker/ticker-add-enabled.php 156
ERROR - 2018-04-16 02:41:33 --> Severity: Notice --> Trying to get property 'cryptocurrency_compare_unit' of non-object /home/dhfwjaco/public_html/application/modules/cryptocurrency/views/ticker/ticker-add-enabled.php 156
ERROR - 2018-04-16 02:41:33 --> Severity: Notice --> Undefined index: enabled_data /home/dhfwjaco/public_html/application/modules/cryptocurrency/views/ticker/ticker-add-enabled.php 156
ERROR - 2018-04-16 02:41:33 --> Severity: Notice --> Trying to get property 'cryptocurrency_compare_unit' of non-object /home/dhfwjaco/public_html/application/modules/cryptocurrency/views/ticker/ticker-add-enabled.php 156
ERROR - 2018-04-16 02:41:33 --> Severity: Notice --> Undefined index: enabled_data /home/dhfwjaco/public_html/application/modules/cryptocurrency/views/ticker/ticker-add-enabled.php 156
ERROR - 2018-04-16 02:41:33 --> Severity: Notice --> Trying to get property 'cryptocurrency_compare_unit' of non-object /home/dhfwjaco/public_html/application/modules/cryptocurrency/views/ticker/ticker-add-enabled.php 156
ERROR - 2018-04-16 03:31:37 --> 404 Page Not Found: ../modules/cryptocurrency/controllers/Cryptocurrency/ticker
ERROR - 2018-04-16 03:31:46 --> 404 Page Not Found: ../modules/cryptocurrency/controllers/Cryptocurrency/ticker
ERROR - 2018-04-16 04:05:58 --> 404 Page Not Found: /index
ERROR - 2018-04-16 05:00:32 --> 404 Page Not Found: /index
ERROR - 2018-04-16 05:06:59 --> 404 Page Not Found: /index
ERROR - 2018-04-16 05:07:04 --> 404 Page Not Found: /index
ERROR - 2018-04-16 05:07:07 --> 404 Page Not Found: /index
ERROR - 2018-04-16 05:07:11 --> 404 Page Not Found: /index
ERROR - 2018-04-16 05:12:39 --> 404 Page Not Found: /index
ERROR - 2018-04-16 06:16:03 --> 404 Page Not Found: /index
ERROR - 2018-04-16 06:16:10 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/dhfwjaco/public_html/application/modules/dashboard/models/Model_account.php 57
ERROR - 2018-04-16 07:39:54 --> 404 Page Not Found: /index
ERROR - 2018-04-16 07:40:02 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/dhfwjaco/public_html/application/modules/dashboard/models/Model_account.php 57
ERROR - 2018-04-16 07:40:03 --> 404 Page Not Found: /index
ERROR - 2018-04-16 09:44:26 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/dhfwjaco/public_html/application/modules/dashboard/models/Model_account.php 57
ERROR - 2018-04-16 14:22:28 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/dhfwjaco/public_html/application/modules/dashboard/models/Model_account.php 57
ERROR - 2018-04-16 16:00:19 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/dhfwjaco/public_html/application/modules/dashboard/models/Model_account.php 57
ERROR - 2018-04-16 16:22:41 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/dhfwjaco/public_html/application/modules/dashboard/models/Model_account.php 57
ERROR - 2018-04-16 16:25:28 --> Severity: Notice --> Undefined index: enabled_data /home/dhfwjaco/public_html/application/modules/cryptocurrency/views/ticker/ticker-add-enabled.php 106
ERROR - 2018-04-16 16:25:28 --> Severity: Notice --> Trying to get property 'cryptocurrency_from_realcurrency' of non-object /home/dhfwjaco/public_html/application/modules/cryptocurrency/views/ticker/ticker-add-enabled.php 106
ERROR - 2018-04-16 16:25:28 --> Severity: Notice --> Undefined index: enabled_data /home/dhfwjaco/public_html/application/modules/cryptocurrency/views/ticker/ticker-add-enabled.php 106
ERROR - 2018-04-16 16:25:28 --> Severity: Notice --> Trying to get property 'cryptocurrency_from_realcurrency' of non-object /home/dhfwjaco/public_html/application/modules/cryptocurrency/views/ticker/ticker-add-enabled.php 106
ERROR - 2018-04-16 16:25:28 --> Severity: Notice --> Undefined index: enabled_data /home/dhfwjaco/public_html/application/modules/cryptocurrency/views/ticker/ticker-add-enabled.php 106
ERROR - 2018-04-16 16:25:28 --> Severity: Notice --> Trying to get property 'cryptocurrency_from_realcurrency' of non-object /home/dhfwjaco/public_html/application/modules/cryptocurrency/views/ticker/ticker-add-enabled.php 106
ERROR - 2018-04-16 16:25:28 --> Severity: Notice --> Undefined index: enabled_data /home/dhfwjaco/public_html/application/modules/cryptocurrency/views/ticker/ticker-add-enabled.php 156
ERROR - 2018-04-16 16:25:28 --> Severity: Notice --> Trying to get property 'cryptocurrency_compare_unit' of non-object /home/dhfwjaco/public_html/application/modules/cryptocurrency/views/ticker/ticker-add-enabled.php 156
ERROR - 2018-04-16 16:25:28 --> Severity: Notice --> Undefined index: enabled_data /home/dhfwjaco/public_html/application/modules/cryptocurrency/views/ticker/ticker-add-enabled.php 156
ERROR - 2018-04-16 16:25:28 --> Severity: Notice --> Trying to get property 'cryptocurrency_compare_unit' of non-object /home/dhfwjaco/public_html/application/modules/cryptocurrency/views/ticker/ticker-add-enabled.php 156
ERROR - 2018-04-16 16:25:28 --> Severity: Notice --> Undefined index: enabled_data /home/dhfwjaco/public_html/application/modules/cryptocurrency/views/ticker/ticker-add-enabled.php 156
ERROR - 2018-04-16 16:25:28 --> Severity: Notice --> Trying to get property 'cryptocurrency_compare_unit' of non-object /home/dhfwjaco/public_html/application/modules/cryptocurrency/views/ticker/ticker-add-enabled.php 156
ERROR - 2018-04-16 17:35:39 --> 404 Page Not Found: /index
