<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-05-15 07:36:34 --> 404 Page Not Found: /index
ERROR - 2018-05-15 07:36:38 --> 404 Page Not Found: /index
ERROR - 2018-05-15 07:36:43 --> 404 Page Not Found: /index
ERROR - 2018-05-15 07:36:53 --> 404 Page Not Found: /index
ERROR - 2018-05-15 07:41:12 --> 404 Page Not Found: /index
ERROR - 2018-05-15 07:41:18 --> 404 Page Not Found: /index
ERROR - 2018-05-15 12:29:55 --> 404 Page Not Found: /index
ERROR - 2018-05-15 12:30:00 --> 404 Page Not Found: /index
ERROR - 2018-05-15 12:31:37 --> 404 Page Not Found: /index
ERROR - 2018-05-15 12:31:47 --> 404 Page Not Found: /index
ERROR - 2018-05-15 16:01:29 --> Severity: error --> Exception: MySQL server has gone away /home/dhfwjaco/public_html/system/database/drivers/mysqli/mysqli_driver.php 305
ERROR - 2018-05-15 16:01:29 --> Severity: error --> Exception: MySQL server has gone away /home/dhfwjaco/public_html/system/database/drivers/mysqli/mysqli_driver.php 305
