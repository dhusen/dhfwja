<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-02-28 09:23:54 --> 404 Page Not Found: ../modules/web/controllers//index
ERROR - 2018-02-28 12:37:41 --> Severity: Notice --> Undefined property: CI::$erro_msg C:\wwwroot\apache\projects\codeigniter\tdp-indonesia\domains\tdpid.project.true\html\application\third_party\MX\Controller.php 59
ERROR - 2018-02-28 12:37:42 --> Severity: Notice --> Indirect modification of overloaded property Menu::$erro_msg has no effect C:\wwwroot\apache\projects\codeigniter\tdp-indonesia\domains\tdpid.project.true\html\application\modules\dashboard\controllers\Menu.php 166
ERROR - 2018-02-28 12:39:23 --> Severity: Notice --> Trying to get property of non-object C:\wwwroot\apache\projects\codeigniter\tdp-indonesia\domains\tdpid.project.true\html\application\modules\dashboard\views\menu\menu-lists-ajax.php 9
ERROR - 2018-02-28 12:39:23 --> Severity: Notice --> Undefined index: pagination C:\wwwroot\apache\projects\codeigniter\tdp-indonesia\domains\tdpid.project.true\html\application\modules\dashboard\views\menu\menu-lists-ajax.php 90
ERROR - 2018-02-28 12:40:17 --> Severity: Notice --> Undefined index: pagination C:\wwwroot\apache\projects\codeigniter\tdp-indonesia\domains\tdpid.project.true\html\application\modules\dashboard\views\menu\menu-lists-ajax.php 90
ERROR - 2018-02-28 16:20:54 --> 404 Page Not Found: ../modules/web/controllers/Game/images
ERROR - 2018-02-28 16:20:54 --> 404 Page Not Found: ../modules/web/controllers/Game/images
ERROR - 2018-02-28 16:20:54 --> 404 Page Not Found: ../modules/web/controllers/Game/images
ERROR - 2018-02-28 16:20:54 --> 404 Page Not Found: ../modules/web/controllers/Game/images
ERROR - 2018-02-28 16:20:54 --> 404 Page Not Found: ../modules/web/controllers/Game/images
ERROR - 2018-02-28 16:20:54 --> 404 Page Not Found: ../modules/web/controllers/Game/images
ERROR - 2018-02-28 16:20:54 --> 404 Page Not Found: ../modules/web/controllers/Game/images
ERROR - 2018-02-28 16:20:54 --> 404 Page Not Found: ../modules/web/controllers/Game/images
ERROR - 2018-02-28 16:21:03 --> 404 Page Not Found: ../modules/web/controllers/Game/images
ERROR - 2018-02-28 16:21:18 --> 404 Page Not Found: ../modules/web/controllers/Game/images
ERROR - 2018-02-28 17:16:47 --> Severity: Notice --> Undefined property: CI::$mod_menu C:\wwwroot\apache\projects\codeigniter\tdp-indonesia\domains\tdpid.project.true\html\application\third_party\MX\Controller.php 59
ERROR - 2018-02-28 17:16:47 --> Severity: error --> Exception: Call to a member function get_banner_location_by() on null C:\wwwroot\apache\projects\codeigniter\tdp-indonesia\domains\tdpid.project.true\html\application\modules\dashboard\controllers\Banner.php 69
ERROR - 2018-02-28 17:17:09 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\wwwroot\apache\projects\codeigniter\tdp-indonesia\domains\tdpid.project.true\html\application\modules\dashboard\controllers\Banner.php:83) C:\wwwroot\apache\projects\codeigniter\tdp-indonesia\domains\tdpid.project.true\html\system\helpers\url_helper.php 564
ERROR - 2018-02-28 17:23:09 --> Severity: Warning --> include(banner/banner-lists.php): failed to open stream: No such file or directory C:\wwwroot\apache\projects\codeigniter\tdp-indonesia\domains\tdpid.project.true\html\application\modules\dashboard\views\dashboard.php 95
ERROR - 2018-02-28 17:23:09 --> Severity: Warning --> include(banner/banner-lists.php): failed to open stream: No such file or directory C:\wwwroot\apache\projects\codeigniter\tdp-indonesia\domains\tdpid.project.true\html\application\modules\dashboard\views\dashboard.php 95
ERROR - 2018-02-28 17:23:09 --> Severity: Warning --> include(): Failed opening 'banner/banner-lists.php' for inclusion (include_path='.;C:\php\pear') C:\wwwroot\apache\projects\codeigniter\tdp-indonesia\domains\tdpid.project.true\html\application\modules\dashboard\views\dashboard.php 95
ERROR - 2018-02-28 17:26:00 --> Severity: Notice --> Undefined index: menu_type_data C:\wwwroot\apache\projects\codeigniter\tdp-indonesia\domains\tdpid.project.true\html\application\modules\dashboard\views\banner\banner-lists.php 169
ERROR - 2018-02-28 17:26:00 --> Severity: Notice --> Trying to get property of non-object C:\wwwroot\apache\projects\codeigniter\tdp-indonesia\domains\tdpid.project.true\html\application\modules\dashboard\views\banner\banner-lists.php 169
ERROR - 2018-02-28 17:26:23 --> Severity: Notice --> Undefined index: menu_type_data C:\wwwroot\apache\projects\codeigniter\tdp-indonesia\domains\tdpid.project.true\html\application\modules\dashboard\views\banner\banner-lists.php 169
ERROR - 2018-02-28 17:26:23 --> Severity: Notice --> Trying to get property of non-object C:\wwwroot\apache\projects\codeigniter\tdp-indonesia\domains\tdpid.project.true\html\application\modules\dashboard\views\banner\banner-lists.php 169
ERROR - 2018-02-28 17:27:00 --> Severity: Notice --> Undefined index: menu_type_data C:\wwwroot\apache\projects\codeigniter\tdp-indonesia\domains\tdpid.project.true\html\application\modules\dashboard\views\banner\banner-lists.php 169
ERROR - 2018-02-28 17:27:00 --> Severity: Notice --> Trying to get property of non-object C:\wwwroot\apache\projects\codeigniter\tdp-indonesia\domains\tdpid.project.true\html\application\modules\dashboard\views\banner\banner-lists.php 169
ERROR - 2018-02-28 17:27:19 --> Severity: Notice --> Undefined index: menu_type_data C:\wwwroot\apache\projects\codeigniter\tdp-indonesia\domains\tdpid.project.true\html\application\modules\dashboard\views\banner\banner-lists.php 169
ERROR - 2018-02-28 17:27:19 --> Severity: Notice --> Trying to get property of non-object C:\wwwroot\apache\projects\codeigniter\tdp-indonesia\domains\tdpid.project.true\html\application\modules\dashboard\views\banner\banner-lists.php 169
ERROR - 2018-02-28 17:27:20 --> Severity: Notice --> Undefined index: menu_type_data C:\wwwroot\apache\projects\codeigniter\tdp-indonesia\domains\tdpid.project.true\html\application\modules\dashboard\views\banner\banner-lists.php 169
ERROR - 2018-02-28 17:27:20 --> Severity: Notice --> Trying to get property of non-object C:\wwwroot\apache\projects\codeigniter\tdp-indonesia\domains\tdpid.project.true\html\application\modules\dashboard\views\banner\banner-lists.php 169
ERROR - 2018-02-28 17:27:50 --> Severity: Notice --> Undefined index: menu_type_data C:\wwwroot\apache\projects\codeigniter\tdp-indonesia\domains\tdpid.project.true\html\application\modules\dashboard\views\banner\banner-lists.php 169
ERROR - 2018-02-28 17:27:50 --> Severity: Notice --> Trying to get property of non-object C:\wwwroot\apache\projects\codeigniter\tdp-indonesia\domains\tdpid.project.true\html\application\modules\dashboard\views\banner\banner-lists.php 169
ERROR - 2018-02-28 17:27:53 --> Severity: Notice --> Undefined index: menu_type_data C:\wwwroot\apache\projects\codeigniter\tdp-indonesia\domains\tdpid.project.true\html\application\modules\dashboard\views\banner\banner-lists.php 169
ERROR - 2018-02-28 17:27:53 --> Severity: Notice --> Trying to get property of non-object C:\wwwroot\apache\projects\codeigniter\tdp-indonesia\domains\tdpid.project.true\html\application\modules\dashboard\views\banner\banner-lists.php 169
ERROR - 2018-02-28 17:31:39 --> Severity: Notice --> Undefined index: menu_type_data C:\wwwroot\apache\projects\codeigniter\tdp-indonesia\domains\tdpid.project.true\html\application\modules\dashboard\views\banner\banner-lists.php 130
ERROR - 2018-02-28 17:31:39 --> Severity: Notice --> Trying to get property of non-object C:\wwwroot\apache\projects\codeigniter\tdp-indonesia\domains\tdpid.project.true\html\application\modules\dashboard\views\banner\banner-lists.php 130
ERROR - 2018-02-28 17:34:06 --> Severity: Notice --> Undefined index: menu_type_data C:\wwwroot\apache\projects\codeigniter\tdp-indonesia\domains\tdpid.project.true\html\application\modules\dashboard\views\banner\banner-lists.php 128
ERROR - 2018-02-28 17:34:06 --> Severity: Notice --> Trying to get property of non-object C:\wwwroot\apache\projects\codeigniter\tdp-indonesia\domains\tdpid.project.true\html\application\modules\dashboard\views\banner\banner-lists.php 128
ERROR - 2018-02-28 17:34:16 --> Severity: Notice --> Undefined index: menu_type_data C:\wwwroot\apache\projects\codeigniter\tdp-indonesia\domains\tdpid.project.true\html\application\modules\dashboard\views\banner\banner-lists.php 128
ERROR - 2018-02-28 17:34:16 --> Severity: Notice --> Trying to get property of non-object C:\wwwroot\apache\projects\codeigniter\tdp-indonesia\domains\tdpid.project.true\html\application\modules\dashboard\views\banner\banner-lists.php 128
ERROR - 2018-02-28 17:36:42 --> Severity: Notice --> Undefined property: CI::$mod_menu C:\wwwroot\apache\projects\codeigniter\tdp-indonesia\domains\tdpid.project.true\html\application\third_party\MX\Controller.php 59
ERROR - 2018-02-28 17:36:42 --> Severity: error --> Exception: Call to a member function get_menu_types() on null C:\wwwroot\apache\projects\codeigniter\tdp-indonesia\domains\tdpid.project.true\html\application\modules\dashboard\controllers\Banner.php 277
ERROR - 2018-02-28 17:50:06 --> Severity: error --> Exception: Unknown table 'b' C:\wwwroot\apache\projects\codeigniter\tdp-indonesia\domains\tdpid.project.true\html\system\database\drivers\mysqli\mysqli_driver.php 305
