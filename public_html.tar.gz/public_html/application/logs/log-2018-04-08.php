<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-04-08 03:54:01 --> 404 Page Not Found: /index
ERROR - 2018-04-08 04:26:57 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/dhfwjaco/public_html/application/modules/dashboard/models/Model_account.php 57
ERROR - 2018-04-08 05:55:00 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/dhfwjaco/public_html/application/modules/dashboard/models/Model_account.php 57
ERROR - 2018-04-08 08:57:26 --> 404 Page Not Found: /index
ERROR - 2018-04-08 08:57:42 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/dhfwjaco/public_html/application/modules/dashboard/models/Model_account.php 57
ERROR - 2018-04-08 08:57:43 --> 404 Page Not Found: /index
ERROR - 2018-04-08 08:57:49 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/dhfwjaco/public_html/application/modules/dashboard/controllers/Profile.php 92
ERROR - 2018-04-08 08:57:49 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/dhfwjaco/public_html/application/modules/dashboard/controllers/Profile.php 99
ERROR - 2018-04-08 08:57:49 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/dhfwjaco/public_html/application/modules/dashboard/controllers/Profile.php 106
ERROR - 2018-04-08 08:57:56 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/dhfwjaco/public_html/application/modules/dashboard/controllers/Profile.php 92
ERROR - 2018-04-08 08:57:56 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/dhfwjaco/public_html/application/modules/dashboard/controllers/Profile.php 99
ERROR - 2018-04-08 08:57:56 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/dhfwjaco/public_html/application/modules/dashboard/controllers/Profile.php 106
ERROR - 2018-04-08 08:58:02 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/dhfwjaco/public_html/application/modules/dashboard/controllers/Profile.php 92
ERROR - 2018-04-08 08:58:02 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/dhfwjaco/public_html/application/modules/dashboard/controllers/Profile.php 99
ERROR - 2018-04-08 08:58:02 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/dhfwjaco/public_html/application/modules/dashboard/controllers/Profile.php 106
ERROR - 2018-04-08 08:58:50 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/dhfwjaco/public_html/application/modules/dashboard/controllers/Profile.php 92
ERROR - 2018-04-08 08:58:50 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/dhfwjaco/public_html/application/modules/dashboard/controllers/Profile.php 99
ERROR - 2018-04-08 08:58:50 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/dhfwjaco/public_html/application/modules/dashboard/controllers/Profile.php 106
ERROR - 2018-04-08 10:49:25 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/dhfwjaco/public_html/application/modules/dashboard/models/Model_account.php 57
ERROR - 2018-04-08 10:50:04 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/dhfwjaco/public_html/application/modules/dashboard/models/Model_account.php 57
ERROR - 2018-04-08 11:32:19 --> 404 Page Not Found: /index
ERROR - 2018-04-08 12:35:27 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/dhfwjaco/public_html/application/modules/dashboard/models/Model_account.php 57
ERROR - 2018-04-08 12:41:20 --> Severity: Notice --> Undefined index: enabled_data /home/dhfwjaco/public_html/application/modules/cryptocurrency/views/ticker/ticker-add-enabled.php 137
ERROR - 2018-04-08 12:41:20 --> Severity: Notice --> Trying to get property 'cryptocurrency_compare_unit' of non-object /home/dhfwjaco/public_html/application/modules/cryptocurrency/views/ticker/ticker-add-enabled.php 137
ERROR - 2018-04-08 12:41:20 --> Severity: Notice --> Undefined index: enabled_data /home/dhfwjaco/public_html/application/modules/cryptocurrency/views/ticker/ticker-add-enabled.php 137
ERROR - 2018-04-08 12:41:20 --> Severity: Notice --> Trying to get property 'cryptocurrency_compare_unit' of non-object /home/dhfwjaco/public_html/application/modules/cryptocurrency/views/ticker/ticker-add-enabled.php 137
ERROR - 2018-04-08 12:41:20 --> Severity: Notice --> Undefined index: enabled_data /home/dhfwjaco/public_html/application/modules/cryptocurrency/views/ticker/ticker-add-enabled.php 137
ERROR - 2018-04-08 12:41:20 --> Severity: Notice --> Trying to get property 'cryptocurrency_compare_unit' of non-object /home/dhfwjaco/public_html/application/modules/cryptocurrency/views/ticker/ticker-add-enabled.php 137
ERROR - 2018-04-08 17:27:49 --> 404 Page Not Found: /index
ERROR - 2018-04-08 17:29:38 --> 404 Page Not Found: /index
ERROR - 2018-04-08 20:41:31 --> 404 Page Not Found: /index
ERROR - 2018-04-08 22:12:03 --> 404 Page Not Found: /index
ERROR - 2018-04-08 22:12:03 --> 404 Page Not Found: /index
