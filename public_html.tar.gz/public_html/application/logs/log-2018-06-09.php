<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-06-09 00:01:13 --> 404 Page Not Found: /index
ERROR - 2018-06-09 10:10:48 --> 404 Page Not Found: /index
ERROR - 2018-06-09 10:11:12 --> 404 Page Not Found: /index
ERROR - 2018-06-09 10:11:13 --> 404 Page Not Found: /index
ERROR - 2018-06-09 11:45:34 --> 404 Page Not Found: /index
ERROR - 2018-06-09 15:49:57 --> 404 Page Not Found: /index
ERROR - 2018-06-09 16:03:10 --> 404 Page Not Found: /index
ERROR - 2018-06-09 20:33:19 --> 404 Page Not Found: /index
ERROR - 2018-06-09 20:33:19 --> 404 Page Not Found: /index
ERROR - 2018-06-09 20:33:27 --> 404 Page Not Found: /index
