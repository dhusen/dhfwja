<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-04-29 01:17:48 --> 404 Page Not Found: /index
ERROR - 2018-04-29 04:04:48 --> 404 Page Not Found: /index
ERROR - 2018-04-29 13:05:29 --> Severity: error --> Exception: JSON decode error /home/dhfwjaco/public_html/application/vendor/psr/payward/kraken-api-client/php/KrakenAPI.php 93
ERROR - 2018-04-29 13:30:19 --> Severity: error --> Exception: JSON decode error /home/dhfwjaco/public_html/application/vendor/psr/payward/kraken-api-client/php/KrakenAPI.php 93
ERROR - 2018-04-29 21:48:26 --> 404 Page Not Found: /index
ERROR - 2018-04-29 21:48:36 --> 404 Page Not Found: /index
