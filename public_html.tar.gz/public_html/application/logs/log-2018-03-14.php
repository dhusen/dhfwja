<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-03-14 22:06:18 --> Severity: error --> Exception: CURL error: Unknown SSL protocol error in connection to api.kraken.com:443  /home/www/domains/myarena.id/domains/mutasi.myarena.id/html/application/vendor/psr/payward/kraken-api-client/php/KrakenAPI.php 88
