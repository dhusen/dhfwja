<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-03-07 16:18:25 --> 404 Page Not Found: /index
ERROR - 2018-03-07 16:18:25 --> 404 Page Not Found: /index
