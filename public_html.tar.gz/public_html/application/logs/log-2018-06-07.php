<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-06-07 14:06:42 --> Severity: error --> Exception: MySQL server has gone away /home/dhfwjaco/public_html/system/database/drivers/mysqli/mysqli_driver.php 305
ERROR - 2018-06-07 17:45:27 --> Severity: error --> Exception: JSON decode error /home/dhfwjaco/public_html/application/vendor/psr/payward/kraken-api-client/php/KrakenAPI.php 93
ERROR - 2018-06-07 21:59:53 --> 404 Page Not Found: /index
ERROR - 2018-06-07 22:10:42 --> 404 Page Not Found: /index
ERROR - 2018-06-07 22:12:13 --> 404 Page Not Found: /index
ERROR - 2018-06-07 22:12:16 --> 404 Page Not Found: /index
ERROR - 2018-06-07 22:12:41 --> 404 Page Not Found: /index
ERROR - 2018-06-07 22:12:56 --> Severity: Notice --> Undefined index: enabled_data /home/dhfwjaco/public_html/application/modules/cryptocurrency/views/ticker/ticker-add-enabled.php 106
ERROR - 2018-06-07 22:12:56 --> Severity: Notice --> Trying to get property of non-object /home/dhfwjaco/public_html/application/modules/cryptocurrency/views/ticker/ticker-add-enabled.php 106
ERROR - 2018-06-07 22:12:56 --> Severity: Notice --> Undefined index: enabled_data /home/dhfwjaco/public_html/application/modules/cryptocurrency/views/ticker/ticker-add-enabled.php 106
ERROR - 2018-06-07 22:12:56 --> Severity: Notice --> Trying to get property of non-object /home/dhfwjaco/public_html/application/modules/cryptocurrency/views/ticker/ticker-add-enabled.php 106
ERROR - 2018-06-07 22:12:56 --> Severity: Notice --> Undefined index: enabled_data /home/dhfwjaco/public_html/application/modules/cryptocurrency/views/ticker/ticker-add-enabled.php 106
ERROR - 2018-06-07 22:12:56 --> Severity: Notice --> Trying to get property of non-object /home/dhfwjaco/public_html/application/modules/cryptocurrency/views/ticker/ticker-add-enabled.php 106
ERROR - 2018-06-07 22:12:56 --> Severity: Notice --> Undefined index: enabled_data /home/dhfwjaco/public_html/application/modules/cryptocurrency/views/ticker/ticker-add-enabled.php 156
ERROR - 2018-06-07 22:12:56 --> Severity: Notice --> Trying to get property of non-object /home/dhfwjaco/public_html/application/modules/cryptocurrency/views/ticker/ticker-add-enabled.php 156
ERROR - 2018-06-07 22:12:56 --> Severity: Notice --> Undefined index: enabled_data /home/dhfwjaco/public_html/application/modules/cryptocurrency/views/ticker/ticker-add-enabled.php 156
ERROR - 2018-06-07 22:12:56 --> Severity: Notice --> Trying to get property of non-object /home/dhfwjaco/public_html/application/modules/cryptocurrency/views/ticker/ticker-add-enabled.php 156
ERROR - 2018-06-07 22:12:56 --> Severity: Notice --> Undefined index: enabled_data /home/dhfwjaco/public_html/application/modules/cryptocurrency/views/ticker/ticker-add-enabled.php 156
ERROR - 2018-06-07 22:12:56 --> Severity: Notice --> Trying to get property of non-object /home/dhfwjaco/public_html/application/modules/cryptocurrency/views/ticker/ticker-add-enabled.php 156
