<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-05-25 09:05:33 --> 404 Page Not Found: /index
ERROR - 2018-05-25 09:05:54 --> 404 Page Not Found: /index
ERROR - 2018-05-25 17:58:43 --> 404 Page Not Found: /index
ERROR - 2018-05-25 17:58:51 --> 404 Page Not Found: /index
ERROR - 2018-05-25 18:37:56 --> 404 Page Not Found: /index
ERROR - 2018-05-25 18:37:56 --> 404 Page Not Found: /index
ERROR - 2018-05-25 18:37:56 --> 404 Page Not Found: /index
ERROR - 2018-05-25 18:37:56 --> 404 Page Not Found: /index
ERROR - 2018-05-25 18:37:56 --> 404 Page Not Found: /index
ERROR - 2018-05-25 18:37:56 --> 404 Page Not Found: /index
ERROR - 2018-05-25 18:37:56 --> 404 Page Not Found: /index
