<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-04-14 02:32:46 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/dhfwjaco/public_html/application/modules/dashboard/models/Model_account.php 57
ERROR - 2018-04-14 09:46:18 --> 404 Page Not Found: /index
ERROR - 2018-04-14 09:52:13 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/dhfwjaco/public_html/application/modules/dashboard/models/Model_account.php 57
ERROR - 2018-04-14 14:51:08 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/dhfwjaco/public_html/application/modules/dashboard/models/Model_account.php 57
ERROR - 2018-04-14 15:41:16 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/dhfwjaco/public_html/application/modules/dashboard/models/Model_account.php 57
ERROR - 2018-04-14 15:42:58 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/dhfwjaco/public_html/application/modules/dashboard/models/Model_account.php 57
ERROR - 2018-04-14 15:44:30 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/dhfwjaco/public_html/application/modules/dashboard/controllers/Users.php 385
ERROR - 2018-04-14 15:44:30 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/dhfwjaco/public_html/application/modules/dashboard/controllers/Users.php 399
ERROR - 2018-04-14 15:45:21 --> Severity: Notice --> Undefined index: enabled_data /home/dhfwjaco/public_html/application/modules/cryptocurrency/views/ticker/ticker-add-enabled.php 106
ERROR - 2018-04-14 15:45:21 --> Severity: Notice --> Trying to get property 'cryptocurrency_from_realcurrency' of non-object /home/dhfwjaco/public_html/application/modules/cryptocurrency/views/ticker/ticker-add-enabled.php 106
ERROR - 2018-04-14 15:45:21 --> Severity: Notice --> Undefined index: enabled_data /home/dhfwjaco/public_html/application/modules/cryptocurrency/views/ticker/ticker-add-enabled.php 106
ERROR - 2018-04-14 15:45:21 --> Severity: Notice --> Trying to get property 'cryptocurrency_from_realcurrency' of non-object /home/dhfwjaco/public_html/application/modules/cryptocurrency/views/ticker/ticker-add-enabled.php 106
ERROR - 2018-04-14 15:45:21 --> Severity: Notice --> Undefined index: enabled_data /home/dhfwjaco/public_html/application/modules/cryptocurrency/views/ticker/ticker-add-enabled.php 106
ERROR - 2018-04-14 15:45:21 --> Severity: Notice --> Trying to get property 'cryptocurrency_from_realcurrency' of non-object /home/dhfwjaco/public_html/application/modules/cryptocurrency/views/ticker/ticker-add-enabled.php 106
ERROR - 2018-04-14 15:45:21 --> Severity: Notice --> Undefined index: enabled_data /home/dhfwjaco/public_html/application/modules/cryptocurrency/views/ticker/ticker-add-enabled.php 156
ERROR - 2018-04-14 15:45:21 --> Severity: Notice --> Trying to get property 'cryptocurrency_compare_unit' of non-object /home/dhfwjaco/public_html/application/modules/cryptocurrency/views/ticker/ticker-add-enabled.php 156
ERROR - 2018-04-14 15:45:21 --> Severity: Notice --> Undefined index: enabled_data /home/dhfwjaco/public_html/application/modules/cryptocurrency/views/ticker/ticker-add-enabled.php 156
ERROR - 2018-04-14 15:45:21 --> Severity: Notice --> Trying to get property 'cryptocurrency_compare_unit' of non-object /home/dhfwjaco/public_html/application/modules/cryptocurrency/views/ticker/ticker-add-enabled.php 156
ERROR - 2018-04-14 15:45:21 --> Severity: Notice --> Undefined index: enabled_data /home/dhfwjaco/public_html/application/modules/cryptocurrency/views/ticker/ticker-add-enabled.php 156
ERROR - 2018-04-14 15:45:21 --> Severity: Notice --> Trying to get property 'cryptocurrency_compare_unit' of non-object /home/dhfwjaco/public_html/application/modules/cryptocurrency/views/ticker/ticker-add-enabled.php 156
ERROR - 2018-04-14 17:05:29 --> 404 Page Not Found: /index
ERROR - 2018-04-14 17:05:44 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/dhfwjaco/public_html/application/modules/dashboard/models/Model_account.php 57
ERROR - 2018-04-14 17:05:44 --> 404 Page Not Found: /index
